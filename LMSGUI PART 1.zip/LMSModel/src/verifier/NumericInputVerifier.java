package verifier;

import javax.swing.InputVerifier;
import javax.swing.JComponent;
import javax.swing.JTextField;

public class NumericInputVerifier extends InputVerifier {

	public NumericInputVerifier(){
		
	}
	
	@Override
	public boolean verify(JComponent input) {
		// TODO Auto-generated method stub
		
		JTextField txt = (JTextField)input;
		
		char [] chars = ((String)txt.getText())
				.trim().toCharArray();
		
		boolean result = true;
		
		for (char c : chars){
			
			if(!Character.isDigit(c)){
				
				result = false;
				
				break;
			}
		}
		
		return result;
	}

}
