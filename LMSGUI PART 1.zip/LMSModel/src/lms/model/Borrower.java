package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.exception.*;

public interface Borrower
{

   public void borrowHolding(Holding holding)
            throws InsufficientCreditException, MultipleBorrowingException;

   public void returnHolding(Holding holding) throws OverdrawnCreditException;

}