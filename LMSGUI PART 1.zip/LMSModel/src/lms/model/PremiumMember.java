package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */


/* premium member extending member abstract class*/

public class PremiumMember extends AbstractMember
{

   public static final String TYPE = "PREMIUM";
   public static final int INITIAL_CREDIT = 45; /* $ */ 

   public PremiumMember(String id, String fullName)
   {

      super(id, fullName, PremiumMember.INITIAL_CREDIT, PremiumMember.TYPE);

   }

 

   /*overriding toString method by appending member type(premium member)*/
   @Override
   public String toString()
   {

      return String.format("%s:%s", super.toString(), this.getType());

   }

}