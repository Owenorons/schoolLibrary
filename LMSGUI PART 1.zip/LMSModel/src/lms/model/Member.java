package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

/*member class extend borrower class 
 * because members borrow holding**/
public interface Member extends Borrower
{

   public int calculateRemainingCredit(int creditToSubtract);

   public BorrowingHistory getBorrowingHistory();

   public Holding[] getCurrentHoldings();

   public String getFullName();

   public int getMaxCredit();

   public String getMemberId();

   public void resetCredit();

  public int getAvaliableCredit();

   public String getType();

}