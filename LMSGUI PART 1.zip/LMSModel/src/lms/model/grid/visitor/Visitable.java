package lms.model.grid.visitor;

public interface Visitable {
	
	public void accept(Visitor visitor);

}
