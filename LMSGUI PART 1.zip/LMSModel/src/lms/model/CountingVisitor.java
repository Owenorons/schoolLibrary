package lms.model;
/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.visitor.Visitor;

public class CountingVisitor implements Visitor{

	private int countBooks = 0;
	private int countVideos = 0;
	
	public CountingVisitor(){
		
	}
	@Override
	public void visit(Book book) {
		// TODO Auto-generated method stub
		countBooks++;
	}

	@Override
	public void visit(Video video) {
		// TODO Auto-generated method stub
		countVideos++;
	}

	  public int getcountBooks(){
		  return countBooks;
	  }
	  
	  public int getcountVideos(){
		  return countVideos;
	  }
	    
}
