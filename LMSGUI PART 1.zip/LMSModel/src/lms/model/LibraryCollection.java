package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import java.util.*;

public class LibraryCollection
{

   private Map<Integer, Holding> holdings;
   private String code;
   private String name;

   /*library collection Constructor */
   public LibraryCollection(String code, String name)
   {

      // Using a LinkedHashMap to keep the keys in the same order.
      this.code = code;
      this.name = name;
      this.holdings = new LinkedHashMap<Integer, Holding>();

   }

   /*add to holding method */
   public boolean addHolding(Holding holding)
   {

      boolean result = false;

      /* add holdings only if not exist*/
      if (!this.holdings.containsValue(holding))
      {
         this.holdings.put(holding.getCode(), holding);
         result = true;
      }

      return result;

   }

   
   /* retrieve all Holdings*/
   public Holding[] getAllHoldings()
   {

      /* if holdings is not empty,
	   returning holding using toArray to convert it to array.*/
      return this.holdings.size() == 0 ? null : this.holdings.values()
               .toArray(
                        new Holding[this.holdings.size()]);

   }

   public Holding getHolding(int code)
   {

      Holding result = null;

      /*using code to search through holding*/
      if (this.holdings.containsKey(code))
    	  
    	  /*if the code is found then retrieve 
    	   * it from a list of holdings*/
         result = this.holdings.get(code);

      return result;

   }
   

   
   /* check if object exist, check if 
    * its not onloan before removing*/
   public boolean removeHolding(Holding holding)
   {

      boolean result = false;

     
     
      if (!holding.isOnLoan() && this.holdings.containsValue(holding))
         this.holdings.remove(holding.getCode());

      return result;

   }
   
   
   /* counting books and videos on holdings 
    * using implementing visitor*/
   
   public int countBooks()
   {

  	 CountingVisitor visitor = new CountingVisitor();
  	 
  	 for (Map.Entry<Integer, Holding> entry : this.holdings.entrySet())
  		 entry.getValue().accept(visitor);
  	 
  	 return visitor.getcountBooks();

   }
   
   
   

   public int countVideos()
   {

	   CountingVisitor visitor = new CountingVisitor();
  	 
  	 for (Map.Entry<Integer, Holding> entry : this.holdings.entrySet())
  		 entry.getValue().accept(visitor);
  	 
  	 return visitor.getcountVideos();

   }
   
   

   /* getter and setters*/

   public String getCode()
   {

      return this.code;

   }

   public String getName()
   {

      return this.name;

   }

   /* using StringBuilder method 
    * to determine display format
    * and what to be display*/

   @Override
   public String toString()
   {

      int i = 0;
      StringBuilder keys = new StringBuilder();

      
      for (Map.Entry<Integer, Holding> entry : this.holdings.entrySet())
      {
         keys.append(entry.getKey());
         
         /* after searching through the list */
         if (++i < this.holdings.size())
            keys.append(",");
      }

      /* if empty no need to append anything */ 
      if (this.holdings.size() == 0)
         return String.format("%s:%s", this.code, this.name);
      else
         return String
                  .format("%s:%s:%s", this.code, this.name, keys.toString());

   }

}