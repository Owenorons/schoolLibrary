package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.util.DateUtil;
import lms.model.visitor.Visitor;

public class Book extends AbstractHolding
{

   public static final String TYPE = "BOOK";
   public static final int LOANFEE = 10; /*$*/ 
   public static final int MAXLOANPERIOD = 28; /*in days*/
   public static final int LATEDAILYRATE = 2; /*$*/ 

   public Book(int code, String title)
   {

      super(code, title, Book.LOANFEE, Book.MAXLOANPERIOD, Book.TYPE);

   }

   /*implementing the abstractHolding
    * override its methods
    * calculate late fee,
    * visitor and clone */

   
   
   /*this calculate late fee by calling the 
    * DateUtil in conjunction with getBrorrowDate*/
   
   @Override
   public int calculateLateFee()
   {

      int lateFee = 0;
      int daysLate =
               DateUtil.getInstance().getElapsedDays(this.getBorrowDate())
                        - MAXLOANPERIOD;
 
 /* if the dayslate is greater than 0 then calculate late 
  * fee if not ignore*/ 
      
      if (daysLate > 0)
         lateFee = daysLate * Book.LATEDAILYRATE;

      return lateFee;

   }

  
   @Override
   public void accept(Visitor visitor){
  	 
  	 visitor.visit(this);
  	 
   }
   


   @Override
   public Object clone(){
  	   	 
  	 return new Book(this.getCode(), this.getTitle());
  	 
   }
   
   @Override
   public String toString()
   {

      return String.format("%s:%s:%s", super.toString(),
                           this.getMaxLoanPeriod(),
                           this.getType());

   }

}
