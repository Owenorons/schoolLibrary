package lms.model.visitor;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.Book;
import lms.model.Video;


public interface Visitor {

	public void visit(Book book);
	public void visit(Video video);
	
}