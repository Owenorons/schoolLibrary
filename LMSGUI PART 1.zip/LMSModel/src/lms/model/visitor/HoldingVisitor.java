package lms.model.visitor;

import java.util.LinkedHashMap;
import java.util.Map;

import lms.model.Book;
import lms.model.Video;
import lms.view.grid.BookCell;
import lms.view.grid.GridCell;
import lms.view.grid.VideoCell;

public class HoldingVisitor implements Visitor {
	
	
	/*using a map*/
	/*naming the map variables*/
	
	private Map<Integer, Book> books;
	private Map<Integer, Video> videos;
	private Map<Integer, GridCell> cells;
	
	

	public HoldingVisitor() {
	
		
		// TODO Auto-generated constructor stub
		
		books = new LinkedHashMap<Integer, Book>();
		videos = new LinkedHashMap<Integer, Video>();
		cells = new LinkedHashMap<Integer, GridCell>();
		
	}
	
	public Book[] getBooks(){
		
		return books.values().toArray(new Book[books.size()]);
	}
	
	
	public Video[] getVideos(){
		
		return videos.values().toArray(new Video[videos.size()]);
	}
	
	public GridCell[] getCells(){
		
		return cells.values().toArray(new GridCell[cells.size()]);
	}

	@Override
	public void visit(Book book) {
		// TODO Auto-generated method stub
		books.put(books.size(), book);
		cells.put(cells.size(),new BookCell(book));
	}
	
	

	@Override
	public void visit(Video video) {
		// TODO Auto-generated method stub
        videos.put(videos.size(), video);
        cells.put(cells.size(), new VideoCell(video));
	}

}
