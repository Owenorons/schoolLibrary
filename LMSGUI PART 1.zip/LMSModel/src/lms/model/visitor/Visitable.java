
	package lms.model.visitor;
	
	/* Owen O. Uwahen
	 * Student No. S3494967
	 * Assignment 1   */
	
	public interface Visitable {

		public void accept(Visitor visitor);
		
	}


