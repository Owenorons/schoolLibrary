package lms.model;

/* Owen O. Uwahen
 * Student No. S3493976
 * Assignment 1 */

import java.util.*;

public class BorrowingHistory
{

   private Map<Integer, HistoryRecord> historyRecords;

   public BorrowingHistory()
   {

      historyRecords = new HashMap<Integer, HistoryRecord>();

   }
  
   /* adding and recording borrowing history */
   public boolean addHistoryRecord(HistoryRecord historyRecord)
   {

      boolean result = false;

      
      if (!this.historyRecords.containsValue(historyRecord))
      {
         this.historyRecords.put(historyRecord.getHolding().getCode(),
                                 historyRecord);
         result = true;
      }

      return result;

   }

   /*calculating total late fee 
    * by pulling history record */
   public int calculateTotalLateFees()
   {

      int result = 0;

      
      for (Map.Entry<Integer, HistoryRecord> entry : this.historyRecords
               .entrySet())
         result += entry.getValue().getFeePayed()
                   - entry.getValue().getHolding().getDefaultLoanFee();

      return result;

   }
   
   

   /* This pull out and displays all history records*/ 
   public HistoryRecord[] getAllHistoryRecords()
   {

      
      return this.historyRecords.size() == 0 ? null : this.historyRecords
               .values().toArray(new HistoryRecord[this.historyRecords.size()]);

   }

   
   /* this get history by accepting integer to retrieve record  */ 
   public HistoryRecord getHistoryRecord(int code)
   {

      HistoryRecord result = null;

       
      if (this.historyRecords.containsKey(code))
         result = this.historyRecords.get(code);

      return result;

   }

}