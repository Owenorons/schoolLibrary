package lms.model;
/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.visitor.Visitor;

public abstract class AbstractHolding implements Holding {

	private int code;
	private String title;
	private int maxLoanPeriod;
	private String borrowDate;
	private int standardLoanFee;
	private String type;
	
	
 /* AbstractHolding constructor */
	public AbstractHolding(int code, String title, int standardLoanFee,
			int maxLoadPeriod, String type) {

		this.code = code;
		this.title = title;
		this.standardLoanFee = standardLoanFee;
		this.maxLoanPeriod = maxLoadPeriod;
		this.type = type;

	}

	/*implementing holding methods*/

	@Override
	public abstract int calculateLateFee();
	
	

	@Override
	public String getType() {

		return this.type;

	}

	@Override
	public String getBorrowDate() {

		return this.borrowDate;

	}

	@Override
	public int getCode() {

		return this.code;

	}

	@Override
	public int getDefaultLoanFee() {

		return this.standardLoanFee;

	}

	@Override
	public int getMaxLoanPeriod() {

		return this.maxLoanPeriod;

	}

	@Override
	public String getTitle() {

		return this.title;

	}
	
	
	/* this set a holing on loan.*/
	@Override
	public boolean isOnLoan() {

		
		return this.borrowDate != null;

	}

	@Override
	public void setBorrowDate(String newDate) {

		this.borrowDate = newDate;

	}

	/*accept visitor method */
	@Override
	public abstract void accept(Visitor visitor);

	

	@Override
	public abstract Object clone();

	@Override
	public String toString() {

		return String.format("%s:%s:%s", this.code, this.title,
				this.standardLoanFee);

	}

}