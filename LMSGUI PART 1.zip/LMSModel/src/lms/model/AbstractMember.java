package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */


import java.util.*;

import lms.model.exception.*;
import lms.model.util.DateUtil;

public abstract class AbstractMember implements Member {

	private String id;
	private String fullName;
	private int remainingCredit;
	private String type;
	private int maxCredit;

	protected BorrowingHistory history;
	protected Map<Integer, Holding> currentLoans;

	/* Abstract member--constructor  */
	public AbstractMember(String id, String fullName,
			int remainingCredit,
			String type) {

		this.id = id;
		this.fullName = fullName;
		this.remainingCredit = this.maxCredit 
				= remainingCredit;
		this.type = type;
		this.history = new BorrowingHistory();
		this.currentLoans = new HashMap<Integer, Holding>();

	}


    /*   this handles member borrowing from holding. 
     * However check if its already on loan */ 
	@Override
	public void borrowHolding(Holding holding)
			throws InsufficientCreditException, 
			MultipleBorrowingException {

		int fee = holding.getDefaultLoanFee();

		/*  check is its on loan  */
		if (this.currentLoans.containsKey(holding.getCode())
				|| this.history.getHistoryRecord(holding.getCode()) != null)
			throw new MultipleBorrowingException();

		 /* its time to check if the borrower
		  *  have enough money   */
		else if (this.getAvaliableCredit() < fee)
			throw new InsufficientCreditException();

		/*  now can borrow if got enough money  */
		this.calculateRemainingCredit(fee);
		
		/*Setting date and set borrowed Holding into 'on loan'.*/
		holding.setBorrowDate(DateUtil.getInstance().getDate());
		this.currentLoans.put(holding.getCode(), holding);

	}

	/*borrower returning holding method */
	@Override
	public void returnHolding(Holding holding) throws OverdrawnCreditException {

		/* calling the calculate late fee method */
		int fee = holding.calculateLateFee();

		

		/*Clone the holding to keep the time it was borrowed.*/
		
		this.history.addHistoryRecord(new HistoryRecord((Holding) holding
				.clone(), holding.getDefaultLoanFee() + fee));

		/* Setting borrow date to null set 
		borrowed holding to 'not on loan')*/
		
		holding.setBorrowDate(null);
		
		/* calling calculate remaining credit 
		 * to deduct late fee */
		this.calculateRemainingCredit(fee);
		
		/* this remove the item from the current loan*/
		this.currentLoans.remove(holding.getCode());

	}

	/* calculating remaining credit of members*/
	
	@Override
	public int calculateRemainingCredit(int IncuredfeeToBeDeducted) {

		this.remainingCredit -= IncuredfeeToBeDeducted;

		return this.remainingCredit;

	}

	/*this returned type of member*/
	
	@Override
	public String getType() {

		return this.type;

	}


	 /*return remaining credit*/
	@Override
	public int getAvaliableCredit() {

		return this.remainingCredit;

	}
	

	@Override
	public BorrowingHistory getBorrowingHistory() {

		return this.history;

	}
	
	
	/* this return array of holding currently on loan*/
	@Override
	public Holding[] getCurrentHoldings() {

		
		return this.currentLoans.size() == 0 ? null : this.currentLoans
				.values().toArray(new Holding[this.currentLoans.size()]);

	}

	@Override
	public String getFullName() {

		return this.fullName;

	}

	@Override
	public int getMaxCredit() {

		return this.maxCredit;

	}

	@Override
	public String getMemberId() {

		return this.id;

	}

	/* reset credit if low by passing
	 * constant maximum credit into remaining credit */
	@Override
	public void resetCredit() {

		this.remainingCredit = this.maxCredit;

	}

	/* overriding toString method to print in
	 * specific string format */

	@Override
	public String toString() {

		return String.format("%s:%s:%s", this.id, this.fullName,
				this.remainingCredit);

	}

}