package lms.model;
/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

public class HistoryRecord
{

   private Holding holding;
   private int feePaid;

   public HistoryRecord(Holding holding, int feePaid)
   {

      this.holding = holding;
      this.feePaid = feePaid;

   }

   public int getFeePayed()
   {

      return this.feePaid;

   }

   public Holding getHolding()
   {

      return this.holding;

   }

/* overriding ToString method append fee pa*/

   @Override
   public String toString()
   {

      return String.format("%s:%s", this.holding.getCode(), this.feePaid);

   }

}