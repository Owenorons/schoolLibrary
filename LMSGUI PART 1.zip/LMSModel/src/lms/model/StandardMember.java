package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.exception.OverdrawnCreditException;

public class StandardMember extends AbstractMember
{

   public static final String TYPE = "STANDARD";
   public static final int INITIAL_CREDIT = 30; /* $*/ 

   public StandardMember(String id, String fullName)
   {

      super(id, fullName, StandardMember.INITIAL_CREDIT, StandardMember.TYPE);

   }



   @Override
   public void returnHolding(Holding holding) throws OverdrawnCreditException
   {

      int fee = holding.calculateLateFee();
     int credit = this.getAvaliableCredit();
      

      /* throw exception if no enough 
       * credit to to pay later fee*/
      if (credit < fee)
         throw new OverdrawnCreditException();
      


      else
      	super.returnHolding(holding);

   }

 
/* appending the standard member type to the toString method*/
   @Override
   public String toString()
   {

      return String.format("%s:%s", super.toString(), this.getType());

   }

}