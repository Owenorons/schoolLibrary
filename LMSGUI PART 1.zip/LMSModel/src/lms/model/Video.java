package lms.model;

/* Owen O. Uwahen
 * Student No. S3494967
 * Assignment 1   */

import lms.model.util.DateUtil;
import lms.model.visitor.Visitor;

public class Video extends AbstractHolding
{

   public static final String TYPE = "VIDEO";
   public static final int MAX_LOAN_PERIOD = 7; /* loan period in days */ 

   public Video(int code, String title, int standardLoanFee)
   {

      super(code, title, standardLoanFee, Video.MAX_LOAN_PERIOD, Video.TYPE);

   }

   
/*this calculate late fee by calling the 
 * DateUtil in conjunction with getBrorrowDate*/ 
   @Override
   public int calculateLateFee()
   {

      int lateFee = 0;
      int daysLate =
               DateUtil.getInstance().getElapsedDays(this.getBorrowDate())
                        - MAX_LOAN_PERIOD;

      /* if the dayslate is greater than 0 then calculate late 
       * fee if not ignore*/ 
      if (daysLate > 0)
         lateFee = daysLate * (this.getDefaultLoanFee() >> 1);

      return lateFee;

   }

  /*override the accept visitor method*/
   @Override
   public void accept(Visitor visitor){
  	 
  	 visitor.visit(this);
  	 
   }
   
  

   @Override
   public Object clone(){
  	   	 
  	 return new Video(this.getCode(), this.getTitle(), this.getDefaultLoanFee());
  	 
   }
   
   @Override
   public String toString()
   {

      return String.format("%s:%s:%s", super.toString(),
                           this.getMaxLoanPeriod(),
                           this.getType());

   }



}