package lms.dialog;



import java.text.ParseException;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.DocumentListener;
import javax.swing.text.MaskFormatter;

/**
 
 * 
 */
@SuppressWarnings("serial")
public class AddHoldingDialog extends FieldsDialog {

	private JLabel iDLabel;
	private JLabel titleLabel;
	private JLabel feeLabel;
	private JFormattedTextField jFormattedTxtID;
	private JTextField titleTextField;
	private JComboBox<String> ComboBoxFee;
	
	public static final char NUMERIC_PLACEHOLDER = '_';
	
	public AddHoldingDialog(JFrame frame, String holdingType){
		
		this(frame, holdingType, null);
		
	}
	
	public AddHoldingDialog(JFrame frame, String holdingType, String[] holdingFees) {
		
		super(frame);
		
		setTitle("Add " + holdingType);
		
		iDLabel = new JLabel(holdingType + " Id:");
		titleLabel = new JLabel(holdingType + " Title:");
		feeLabel = new JLabel(holdingType + " Fee:");		
		// Mask the input for 7 digits.
		jFormattedTxtID = new JFormattedTextField(createFormatter("#######"));	
		
		titleTextField = new JTextField("", AbstractDialog.DEFAULT_TEXTFIELD_COLUMNS_WIDTH);
		// Only add the items to the comboBox if they are not null.
		ComboBoxFee = holdingFees == null ? new JComboBox<String>() : new JComboBox<String>(holdingFees);			
		
		// Set the width because we can't set it in constructor like JTextField.
		jFormattedTxtID.setColumns(AbstractDialog.DEFAULT_TEXTFIELD_COLUMNS_WIDTH);
		
		// Set the custom input verifiers.
		jFormattedTxtID.setInputVerifier(new NumericInputVerifier());
		titleTextField.setInputVerifier(new LengthInputVerifier(3, 0));
		
		// Get document listener.
		DocumentListener listener = createDocumentListener();
		
		// Add the listener to the text field's document.
		jFormattedTxtID.getDocument().addDocumentListener(listener);
		titleTextField.getDocument().addDocumentListener(listener);
		
		// Add the label and text field (with suggestions).
		addField(iDLabel, jFormattedTxtID, new JLabel("7 digits only. Eg: 1234567"));
		addField(titleLabel, titleTextField, new JLabel("All chars allowed. Min: 3"));
		
		// If this holding has multiple selections for fees, show it.
		if (holdingFees != null){
			addField(feeLabel, ComboBoxFee, new JLabel("Australian Dollars (AUD)"));
			// Disable the component if only 1 value is present.
			if (ComboBoxFee.getItemCount() == 1)
				ComboBoxFee.setEnabled(false);
		}
		
		display();
		
	}
	
	@Override
	public void checkComponents(){
	
		// This method is called by the superclass AbstractDialog
		// when activity happens within the selected text fields.
		
		getOkButton().setEnabled(
			jFormattedTxtID.getInputVerifier().verify(jFormattedTxtID) && 
			titleTextField.getInputVerifier().verify(titleTextField)
		);
		
	}
	
	public String getHoldingId(){
		
		return getHoldingId(false);
		
	}
	
	public String getHoldingTitle(){
		
		return getHoldingTitle(false);
		
	}
	
	public String getHoldingFee(){
		
		return getHoldingFee(false);
		
	}
	
	public String getHoldingId(boolean getLabel){
		
		// Either return the label minus the : at the end, or return the text value.
		return getLabel ? iDLabel.getText().replace(":", "") : jFormattedTxtID.getText().trim();
		
	}
	
	public String getHoldingTitle(boolean getLabel){
		
		// Either return the label minus the : at the end, or return the text value.
		return getLabel ? titleLabel.getText().replace(":", "") : titleTextField.getText();
		
	}
	
	public String getHoldingFee(boolean getLabel){
		
		// Either return the label minus the : at the end, or return the text value.
		return getLabel ? feeLabel.getText().replace(":", "") : ComboBoxFee.getItemAt(ComboBoxFee.getSelectedIndex());
		
	}

	protected MaskFormatter createFormatter(String s){
		
		MaskFormatter formatter = null;
		
		// Try to create formatter, based on supplied mask.
		try {
			
			formatter = new MaskFormatter(s);	
			formatter.setPlaceholderCharacter(NUMERIC_PLACEHOLDER);
			
		} catch (ParseException ex){}
		
		return formatter;
		
	}
	
}