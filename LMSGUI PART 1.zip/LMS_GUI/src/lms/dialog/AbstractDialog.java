package lms.dialog;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

@SuppressWarnings("serial")
public abstract class AbstractDialog extends JDialog implements ActionListener {

	private JFrame frame;
	private JPanel panelButton;
	private JPanel contentPanel;
	private JPanel mainPanel;
	private JPanel innerPanelButtons;
	
	private JButton okButton;
	private JButton cancelButton;
	private Actions result;
	
	public static final int DEFAULT_TEXTFIELD_COLUMNS_WIDTH = 20; // JTextField width
	
	public AbstractDialog() {
		// TODO Auto-generated constructor stub
	}

	public AbstractDialog(JFrame frame) {
		super(frame, true);
		// TODO Auto-generated constructor stub
	}

	
	public static enum Actions {
		OK,
		Cancel
	}
	
	
	public AbstractDialog(JFrame frame, boolean modal) {
		super(frame, modal);
		// TODO Auto-generated constructor stub
		
		this. frame = frame;
		/*Create components*/
		result = Actions.Cancel;
		okButton = new JButton(Actions.OK.name());
		cancelButton = new JButton(Actions.Cancel.name());
		
		/*initialize the JPanels*/
		
		panelButton = new JPanel ();
		contentPanel = new JPanel ();
		mainPanel = new JPanel ();
		innerPanelButtons = new JPanel ();
		
		/*action commands*/
		cancelButton.setActionCommand(Actions.Cancel.name());
		okButton.setActionCommand(Actions.OK.name());
		
		/*its time to add Button Listeners*/
		cancelButton.addActionListener(this);
		okButton.addActionListener(this);
		
		/*setting Mnemonic*/
		cancelButton.setMnemonic('C');
		okButton.setMnemonic('O');
		
		/*adding cancel and ok button to inner
		 * Panel component*/
		
		innerPanelButtons.add(okButton);
		innerPanelButtons.add(cancelButton);
		
		/*now its time to set the layout*/
		
		panelButton.setLayout(new BorderLayout());
		panelButton.add(innerPanelButtons, BorderLayout.EAST);
		
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		
		contentPanel.setLayout(new GridLayout(0,1));
		contentPanel.setBorder(BorderFactory.createEmptyBorder(5,5,0,5));
		
		/*set default button*/
		getRootPane().setDefaultButton(okButton);
		
	}

	
	// Override this function to enable/disable cmdOk
	public void checkComponents(){
		
	}

	/*getter for contentPanel*/
	
	public JPanel getContentPanel(){
		
		return contentPanel;
	}
	
	public void display(){
		
		display(contentPanel);
		
	}
	
public void display(JPanel content){
	mainPanel.removeAll();
		
		mainPanel.add(content);
		mainPanel.add(panelButton, BorderLayout.SOUTH);
		
		add(mainPanel);
		
		// By default, I have chosen to disable this button until
				// valid data has been entered into the dialog.
				// To override this behavior, just enable it in the
				// sub classed constructor.
				okButton.setEnabled(false);
				// Call checkComponents immediately.
				checkComponents();
				
				reDisplay();
				
			}
		


	
	
public void reDisplay(){
		
		result = Actions.Cancel;
		
		pack();
		setMinimumSize(new Dimension(
				innerPanelButtons.getWidth() + 27, 
			contentPanel.getHeight() + (panelButton.getHeight() << 1) + 12
		));
		
		
		setVisible(true);
		setLocationRelativeTo(frame);
		
	}
	
protected JButton getOkButton(){
	
	return this.okButton;
	
}
public Actions getResult(){
	
	return result;
	
} 

public DocumentListener createDocumentListener(){
	
	/*checking the OK Button*/
	
	DocumentListener listener = new DocumentListener(){

		@Override
		public void changedUpdate(DocumentEvent arg0) {
			checkComponents();		
		}

		@Override
		public void insertUpdate(DocumentEvent arg0) {
			checkComponents();				
		}

		@Override
		public void removeUpdate(DocumentEvent arg0) {
			checkComponents();				
		}
		
	};
	
	return listener;
	
}


private void handleOkAction(){
	
	result = Actions.OK;
	setVisible(false);
	
}
private void handleCancelAction(){
	
	result = Actions.Cancel;
	setVisible(false);
	
}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	// Pass the buck to the internal implementations.
		
		if (e.getActionCommand().equals(Actions.OK.name()))
			handleOkAction();
		
		else if (e.getActionCommand().equals(Actions.Cancel.name()))
			handleCancelAction();
		
	}

	}


