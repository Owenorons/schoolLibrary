package lms.view.grid;


public interface GridListener {

	/*the class inform listeners when the grid changes*/ 
	
	public static enum GridState {
		uninitialised, 		// No items, no collection - nothing.
		empty,				// Collection has been created.
		noBooks, 			// No books.
		noVideos, 			// No videos.
		initialised 		// Fully operational.
	}
	
	// Interested parties can listen for this event.
	public void gridChanged(GridState state);
	
}