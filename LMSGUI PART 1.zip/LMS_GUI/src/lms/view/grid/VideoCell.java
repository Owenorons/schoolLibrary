package lms.view.grid;

import java.awt.Color;

import javax.swing.BorderFactory;

import lms.model.Video;

public class VideoCell extends HoldingCell {
	
	public VideoCell(Video model) {
		super(model);
		// TODO Auto-generated constructor stub
		/*set default border to RED*/
		setBorder(BorderFactory.createLineBorder(Color.RED,  DEFAULT_BORDER_SIZE));
	}

	
}


