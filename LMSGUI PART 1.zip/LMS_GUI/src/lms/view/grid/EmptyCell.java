package lms.view.grid;

import java.awt.Color;

import lms.model.visitor.Visitable;
import lms.model.visitor.Visitor;

/*this class handles the empty cell*/

@SuppressWarnings("serial")
public class EmptyCell extends GridCell implements Visitable {

	
	public EmptyCell() {
		// TODO Auto-generated constructor stub
	/*sets the background color to white*/
		
		setBackground(Color.WHITE);
	}
	@Override
	public void accept(Visitor visitor){
		
		accept(visitor);
	}
}
