package lms.view.grid;

import java.awt.Color;

import javax.swing.BorderFactory;

import lms.model.Book;

/*this BookCell class holds the book in each cell 
 * and set the default borderLine to blue */

@SuppressWarnings("serial")
public class BookCell extends HoldingCell {

	public BookCell(Book model) {
		super(model);
		// TODO Auto-generated constructor stub
		/*set default border to BLUE*/
		setBorder(BorderFactory.createLineBorder(Color.BLUE, DEFAULT_BORDER_SIZE));
	}

}
