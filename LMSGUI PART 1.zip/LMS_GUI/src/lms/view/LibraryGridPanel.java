package lms.view;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;

import lms.controller.LibraryGridPanelController;
import lms.model.grid.visitor.HoldingCellVisitor;
import lms.view.grid.GridCell;
import lms.view.grid.HoldingCell;

@SuppressWarnings("serial")
public class LibraryGridPanel extends JPanel {
	
/*private JLabel holdingID = new JLabel("Holding ID:");
	
	private JLabel title = new JLabel("Title:");
	private JLabel StandardLoanFee = new JLabel("Standard Loan Fee:");
	private JLabel loanPeriod = new JLabel("Loan Fee:");
	private JTextField holdingIDField = new JTextField("");
	private JTextField titleField = new JTextField("");
	private JTextField standardLoanFeeField = new JTextField("");
	private JTextField loanPeriodField = new JTextField("");*/	
	
	
	private LibraryGridPanelController libraryGridPanelController ;
	
	public LibraryGridPanel (LMSMainView lmsMainView){
		
		libraryGridPanelController  = new LibraryGridPanelController(lmsMainView);
		//setLayout (new GridLayout(4,3));
		setDoubleBuffered(true);
		setBackground(Color.LIGHT_GRAY);
		
		/*
		title.setHorizontalAlignment(JLabel.LEFT);
		StandardLoanFee.setHorizontalAlignment(JLabel.LEFT);
		loanPeriod.setHorizontalAlignment((int) JLabel.LEFT);
		loanPeriod.setForeground(Color.RED);
		add(title);
		add(StandardLoanFee);
		add(loanPeriod);*/
		
		
	}

	public void update(GridCell[] cells){
		
		removeAll();
		setLayout(new GridLayout(0,LibraryGridPanelController.MAX_CELL_PER_COLUMN, 1,1));
	   
		
		HoldingCellVisitor visitor = new HoldingCellVisitor();
	  /* adding cells and get holdingcells*/
		for (GridCell cell : cells){
			
			cell.accept(visitor);
			add(cell);
		}
				
	HoldingCell[] holdingCells = visitor.getHoldingCells();		
		
		 /*Add mouseListener to HoldingCells.*/
		for (HoldingCell cell : holdingCells)
			cell.getHoldingCellLabel().addMouseListener(libraryGridPanelController);
		
		// This is here because it wasn't removing all the cells
		// on the last row, when an item has been removed.
		repaint();
		}
	
	
	
	public void refresh(GridCell[] cells){
		
		removeAll();		
		
		// Just add the cells without adding listener.
		for (GridCell cell : cells)
			add(cell);
		
	}
	}
	
	
	


