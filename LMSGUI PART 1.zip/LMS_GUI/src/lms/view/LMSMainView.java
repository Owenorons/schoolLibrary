package lms.view;
import lms.view.MenuBar;
import lms.view.LibraryGridPanel;
import lms.view.StatusBar;
import lms.view.ToolBar;
import lms.view.grid.GridCell;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

import lms.model.facade.LMSModel;

@SuppressWarnings("serial")
public class LMSMainView extends JFrame {
	
	//private AddCollectionPanel mainPanel;

	private LMSModel model;
	private MenuBar menuBar;
	private StatusBar statusBar;
	private ToolBar toolBar;
	private LibraryGridPanel libraryGridPanel;
	
	
	@SuppressWarnings("unused")
	public LMSMainView (LMSModel model, String title){
		super(title);
		
		this.model = model;
		
		this.setSize(900, 600);
		
		
		menuBar = new MenuBar(this);
		toolBar = new ToolBar(this);
		libraryGridPanel = new LibraryGridPanel(this);
        statusBar = new StatusBar(this);
		
		JPanel contentPane = (JPanel) getContentPane();
		setLayout (new BorderLayout());	
		
		contentPane.add(toolBar, BorderLayout.NORTH);
		contentPane.add(libraryGridPanel, BorderLayout.CENTER);
		contentPane.add(statusBar, BorderLayout.SOUTH);
		
		//this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		//this.setLocationRelativeTo(lmsMainView);
        //this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        
        this.addWindowListener(new WindowAdapter(){
        	public void windowClosing (WindowEvent e){
        		System.exit(0);
        	}
        });
        
		
		this.validate();
		
        //this.pack();
	}


	public LMSModel getModel() {
		return model;
	}


	public MenuBar getMebuBar() {
		return menuBar;
	}


	public StatusBar getStatusBar() {
		return statusBar;
	}


	public ToolBar getToolBar() {
		return toolBar;
	}


	public LibraryGridPanel getLibraryGridPanel() {
		return libraryGridPanel;
	}


	public void clearLibraryGrid() {
		// TODO Auto-generated method stub
		
	}


	public Object getController() {
		// TODO Auto-generated method stub
		return null;
	}


	public void updateStatusBar(String[] statusData) {
		// TODO Auto-generated method stub
		
	}


	public void updateLibraryGrid(GridCell[] cells) {
		// TODO Auto-generated method stub
		
	}
}
