package lms.view;

import javax.swing.JMenuBar;

public class MenuBar extends JMenuBar {

	public MenuBar(LMSMainView lmsMainView) {
		// TODO Auto-generated constructor stub
	}

}
