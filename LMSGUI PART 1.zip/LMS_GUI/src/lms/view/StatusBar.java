package lms.view;

import java.awt.Color;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public class StatusBar extends JPanel {
	
	public StatusBar(LMSMainView lmsMainView){
this.setBackground(Color.GREEN);
	}
}
