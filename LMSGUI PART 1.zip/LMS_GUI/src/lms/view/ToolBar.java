package lms.view;

import java.awt.Color;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import lms.controller.ToolBarButtonController;
import lms.controller.ToolBarRadioButtonController;

import java.awt.BorderLayout;

@SuppressWarnings("serial")
public class ToolBar extends JPanel {
	
	
	/*  creating and naming panel*/
	private JPanel leftPanel;
	
	private JPanel rightPanel;
	private JPanel rightLowerPanel;
	
	private LMSMainView lmsMainView;
	 
	
	/*  creating Sort Order RadioButton*/
	private JRadioButton radioButtonOfNone;
	private JRadioButton radioButtonOfCode;
	private JRadioButton radioButtonOfType;

	private ButtonGroup RadioButtonPanelGrouped;
	
	
	private JLabel SortOrderLabelTittle;
	
	
	
	
	/*  creating and naming Button*/
	 
	private JButton initializeButton;
	private JButton addBookButton;
	private JButton removeBookButton;
	private JButton addVideoButton;
	private JButton removeVideoButton;
	
	
	/*naming Controller variable*/
	
	private ToolBarButtonController buttonController;
	private ToolBarRadioButtonController RadioButtonController;
	
	/*constructor*/
	public ToolBar(LMSMainView lmsMainView){
		
		/*initializing panel*/
		this.lmsMainView = lmsMainView;
		//this.setBackground(Color.YELLOW);
		
		this.buttonController = new ToolBarButtonController(this);
		this.rightPanel = new JPanel();
		this.leftPanel = new JPanel();
		this.rightLowerPanel = new JPanel();
		
		/*initializing Button*/
		//initializeButton = new JButton(new ImageIcon(getClass().getResource("/img/collection.png")));
		initializeButton =new JButton ("Initialize");//(new ImageIcon(getClass.().getResource("/img/collection.png")));
		addBookButton = new JButton("Addbook");
		removeBookButton = new JButton ("Removebook");
		addVideoButton = new JButton ("Addvideo");
		removeVideoButton = new JButton ("Removevideo");
		
		/*initializing the already created label*/
		radioButtonOfNone = new JRadioButton ("None");
		radioButtonOfCode = new JRadioButton ("Code");
		radioButtonOfType = new JRadioButton ("Type");

		RadioButtonPanelGrouped = new ButtonGroup();
		
		
		SortOrderLabelTittle = new JLabel ("Sort Order");
		
		
		
		
		
		setLayout(new BorderLayout());
		
		rightPanel.setLayout(new BorderLayout());
		
		/*its time to add the component to the left panel*/
		
		leftPanel.add(initializeButton);
		leftPanel.add(addBookButton);
		leftPanel.add(removeBookButton);
		leftPanel.add(addVideoButton);
		leftPanel.add(removeVideoButton);
		
		
		/*grouping the radioButtons before adding to a component*/
		
		RadioButtonPanelGrouped.add(radioButtonOfNone);
		RadioButtonPanelGrouped.add(radioButtonOfCode);
		RadioButtonPanelGrouped.add(radioButtonOfType);
		
		/* after grouping the radioButtons now its time 
		 * to add to the right lower panel*/
		
		
		rightLowerPanel.add(radioButtonOfNone);
		rightLowerPanel.add(radioButtonOfCode);
		rightLowerPanel.add(radioButtonOfType);
		
		rightPanel.add(SortOrderLabelTittle, BorderLayout.NORTH);
		rightPanel.add(rightLowerPanel, BorderLayout.SOUTH);
		
		add(leftPanel, BorderLayout.WEST);
		add(rightPanel,BorderLayout.EAST);
		
		
		
	}
	
	public JRadioButton getRadioButtonOfNone() {
		return radioButtonOfNone;
	}

	public JRadioButton getRadioButtonOfCode() {
		return radioButtonOfCode;
	}

	public JRadioButton getRadioButtonOfType() {
		return radioButtonOfType;
	}

	public ButtonGroup getRadioButtonPanelGrouped() {
		return RadioButtonPanelGrouped;
	}

	public JLabel getSortOrderLabelTittle() {
		return SortOrderLabelTittle;
	}

	public JButton getinitializeButton() {
		return initializeButton;
	}

	public JButton getAddBookButton() {
		return addBookButton;
	}

	public JButton getRemoveBookButton() {
		return removeBookButton;
	}

	public JButton getAddVideoButton() {
		return addVideoButton;
	}

	public JButton getRemoveVideoButton() {
		return removeVideoButton;
	}

	public ToolBarButtonController getButtonController() {
		return buttonController;
	}

	public ToolBarRadioButtonController getRadioButtonController() {
		return RadioButtonController;
	}

	public JPanel getLeftPanel() {
		return leftPanel;
	}

	public JPanel getRightPanel() {
		return rightPanel;
	}

	public JPanel getRightLowerPanel() {
		return rightLowerPanel;
	}

	public ToolBarButtonController getController() {
		return buttonController;
	}

	public LMSMainView getLmsMainView() {
		return lmsMainView;
	}


}
