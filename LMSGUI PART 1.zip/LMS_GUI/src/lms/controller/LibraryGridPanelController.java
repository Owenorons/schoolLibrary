package lms.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;

import lms.utility.ControllerUtility;
import lms.view.LMSMainView;
import lms.view.grid.HoldingCell;

public class LibraryGridPanelController extends MouseAdapter implements ActionListener {

	public static final int MAX_CELL_PER_COLUMN = 4;
	
	private ControllerUtility helper;

	public LibraryGridPanelController(LMSMainView lmsmainView) {
		// TODO Auto-generated constructor stub
		
		helper = new ControllerUtility (lmsmainView);
	}

	
	/*this method help to remove holding using mouse*/
	private void handleRemoveHoldingAction(MouseEvent e) {
		// TODO Auto-generated method stub
		
		JLabel source = (JLabel)e.getSource();
		HoldingCell cell = (HoldingCell)source.getParent().
				getParent().getParent();
		
		helper.removeHolding(cell.getModel().getCode());
		
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getButton() == MouseEvent.BUTTON1)
			handleRemoveHoldingAction(e);
	}

	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
