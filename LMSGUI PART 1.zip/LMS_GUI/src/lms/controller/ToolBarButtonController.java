package lms.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import lms.model.facade.LMSModel;
import lms.view.ToolBar;
import lms.view.grid.GridListener;

public class ToolBarButtonController implements ActionListener, GridListener {
	
	private ToolBar toolBar;

	public ToolBarButtonController(ToolBar toolBar) {
		// TODO Auto-generated constructor stub
		
		this.toolBar = toolBar;
		/* ACCESS MODEL*/
		LMSModel model = this.toolBar.getLmsMainView().getModel();
		this.toolBar.getLmsMainView().getLibraryGridPanel();
		this.toolBar.getLmsMainView().getStatusBar();
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}
	@Override
	public void gridChanged(GridState state) {
		// TODO Auto-generated method stub
		
	}

}
