package lms.main;

import lms.model.facade.LMSFacade;
import lms.model.facade.LMSModel;
import lms.view.LMSMainView;

public class LMSDriver {
	
	public static void main(String [] args){
		LMSModel model = new LMSFacade();
		LMSMainView lmsMainView = new LMSMainView(model, "Assignment 2/Owen");
		
		lmsMainView.setVisible(true);
	}

}
